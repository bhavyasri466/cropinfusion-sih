import 'package:flutter/material.dart';

class HomeControllers {
  static  TextEditingController soilType = TextEditingController();

  static  TextEditingController plantStage = TextEditingController();

  static  TextEditingController location = TextEditingController();

  static  TextEditingController pinCode = TextEditingController();

}