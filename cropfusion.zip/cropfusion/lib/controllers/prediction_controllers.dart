import 'package:flutter/material.dart';

class PredictionControllers {
   static  TextEditingController diseaseName = TextEditingController();

  static  TextEditingController nValue = TextEditingController();

  static  TextEditingController pValue = TextEditingController();

  static  TextEditingController kValue = TextEditingController();

}