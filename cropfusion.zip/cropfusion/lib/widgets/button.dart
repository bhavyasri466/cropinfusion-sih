import 'package:cropfusion/utils/export.dart';
import 'package:flutter/material.dart';

class Button extends StatelessWidget {
Function()? function;
String text;
   Button({super.key,required this.text, this.function});

  @override
  Widget build(BuildContext context) {
    return  InkWell(
      onTap: function,
      child: Container(
                  width: 112,
                  height: 32,
                  decoration: const BoxDecoration(
                      color: AppColors.buttonColor,
                      borderRadius: BorderRadius.all(Radius.circular(5))),
                  child:  Center(
                    child: Text(text,style: TextStyles.buttonText,),
                  ),
                ),
    );
  }
}