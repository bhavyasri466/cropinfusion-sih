import 'package:flutter/material.dart';

class Feilds extends StatefulWidget {
  final Widget? icon = null;
  final String hint;
  final TextEditingController controller;
  void Function(String)? function ;
  Feilds({super.key,required this.hint,required this.controller,this.function,});

  @override
  State<Feilds> createState() => _FeildsState();
}

class _FeildsState extends State<Feilds> {
  @override
  Widget build(BuildContext context) {
    return  TextField(
      
       onChanged: widget.function,
      decoration: InputDecoration(
        hintText: widget.hint,
        icon: widget.icon,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(5),

        )
      ),
    );
  }
}