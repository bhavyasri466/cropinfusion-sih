import 'package:cropfusion/utils/export.dart';
import 'package:flutter/material.dart';

class Header extends StatelessWidget {
  String title;
   Header({
    super.key,
    this.title = Strings.diseasePrediction
  });

  @override
  Widget build(BuildContext context) {
    return Flex(
      direction: Axis.horizontal,
      children: [
        Image.asset(
          Images.logo,
          scale: 2,
        ),
        Expanded(
            child: Center(
                child: Text(
          title,
          style: TextStyles.redText,
        ))),
      ],
    );
  }
}
