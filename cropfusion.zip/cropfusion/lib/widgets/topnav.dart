import 'package:cropfusion/utils/export.dart';
import 'package:flutter/material.dart';

class TopNav extends StatelessWidget implements PreferredSizeWidget {
  bool aautoImplyLeading;
  TopNav({super.key, this.aautoImplyLeading = false});

  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: AppColors.buttonColor,
      automaticallyImplyLeading: aautoImplyLeading,
      actions: [
        const Text(
          "Home",
          style: TextStyles.appbarText,
        ),
        Gaps.width(10),
        const Text(
          "Prediction Form",
          style: TextStyles.appbarText,
        ),
        Gaps.width(10),
        const Text(
          "Result",
          style: TextStyles.appbarText,
        ),
        Gaps.width(10),
        const Text(
          "Language",
          style: TextStyles.appbarText,
        ),
        Gaps.width(10),
      ],
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(38);
}
