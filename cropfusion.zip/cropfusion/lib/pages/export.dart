export './home.dart';
export './login.dart';
export './splash.dart';
export './prevention.dart';
export './prediction.dart';