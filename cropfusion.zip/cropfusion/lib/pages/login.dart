import 'package:flutter/material.dart';

//Custom Imports
import 'package:cropfusion/utils/export.dart';
import 'package:cropfusion/widgets/export.dart';

//Next Page
import './home.dart';

class Login extends StatefulWidget {
  const Login({super.key});

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  TextEditingController mobileNumberCtrl = TextEditingController();
  TextEditingController otpCtrl = TextEditingController();
  bool loginClicked = false;
  bool disabled = true;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
    body: Stack(

        children: [
    
          Positioned(
            bottom: 0,
            right: 0,
            child:  Image.asset(Images.transparentFarmers),
          ),
          Column(
            children: [
              Image.asset(
                Images.boardingCropImage,
                width: double.infinity,
                fit: BoxFit.cover,
                opacity: const AlwaysStoppedAnimation(0.5),
              ),
              Gaps.height(45),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 11),
                child: Column(
                  children: [
                    const Text(
                      Strings.login,
                      style: TextStyle(
                        color: AppColors.highLightTextColor,
                        fontFamily: 'Instrument Serif',
                      ),
                    ),
                    Gaps.height(26),
                    Feilds(hint: !loginClicked ?'Mobile Number' : 'Enter OTP',controller: 
                   !loginClicked? mobileNumberCtrl:otpCtrl,function: (p0) {
                     if ((p0.length > 10 || p0.length < 10) && p0[0] == '0' ) {
                       
                     }
                   }, ),
                   Gaps.height(20),
                    InkWell(
                onTap: (){

                  setState(() {
                    loginClicked = !loginClicked;
                  });
                  if (loginClicked) {
                    Navigator.push(context, MaterialPageRoute(builder: (ctx)=>const Home()));
                  }
                },
                child: Container(
                  width: 112,
                  height: 32,
                  decoration: const BoxDecoration(
                      color: AppColors.buttonColor,
                      borderRadius: BorderRadius.all(Radius.circular(5))),
                  child:  Center(
                    child: Text( loginClicked ? 'Login' : 'Get OTP'),
                  ),
                ),
              ),
            
                  ],
                ),
              )
            ],
          ),
         Positioned(
          top: MediaQuery.of(context).padding.top,
          left: MediaQuery.of(context).padding.left -30,
           child: Image.asset(
                  Images.logo,),
         ),
        ],
      ),);
  }
}
