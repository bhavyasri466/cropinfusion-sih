import 'package:flutter/material.dart';

//Custom imports
import 'package:cropfusion/utils/export.dart';

//Next Page
import './login.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Positioned(
            bottom: 0,
            right: 0,
            child:  Image.asset(Images.transparentFarmers),
          ),
          Column(
            children: [
              Image.asset(
                Images.boardingCropImage,
                width: double.infinity,
                fit: BoxFit.cover,
              ),
              Gaps.height(45),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 11),
                child: Column(
                  children: [
                    const Text(
                      Strings.welcomeToCropInfusion,
                      style: TextStyle(
                        color: AppColors.highLightTextColor,
                        fontFamily: 'Instrument Serif',
                      ),
                    ),
                    Gaps.height(26),
                    const Text(
                      Strings.boardingText,
                      textAlign: TextAlign.justify,
                    )
                  ],
                ),
              )
            ],
          ),
          Positioned(
            width: MediaQuery.of(context).size.width,
            bottom: 28,
            left: 0,
            child: Center(
              child: InkWell(
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (ctx)=>const Login()));
                },
                child: Container(
                  width: 112,
                  height: 32,
                  decoration: const BoxDecoration(
                      color: AppColors.buttonColor,
                      borderRadius: BorderRadius.all(Radius.circular(5))),
                  child: const Center(
                    child: Text("Get Started"),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
