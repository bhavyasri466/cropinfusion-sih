import 'package:flutter/material.dart';

//Custom Imports
import 'package:cropfusion/utils/export.dart';
import 'package:cropfusion/widgets/export.dart';
import 'package:cropfusion/sample_data/export.dart';

//Next Page
import 'home.dart';

class Prevention extends StatefulWidget {
  const Prevention({super.key});

  @override
  State<Prevention> createState() => _PreventionState();
}

class _PreventionState extends State<Prevention> {
  List<Map<String, dynamic>> preventionMethodsList = [];

  @override
  void initState() {
    setState(() {
      preventionMethodsList = preventionMethods['data'];
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: TopNav(),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Header(
              title: Strings.preventionMethods,
            ),
            Gaps.height(20),
            for (int i = 0; i < preventionMethodsList.length; i++) ...{
              Text(
                "${preventionMethodsList[i]['heading']} :",
                style: TextStyles.redText,
              ),
              Gaps.height(10),
              for (int j = 0;
                  j < preventionMethodsList[i]['methods'].length;
                  j++) ...{
                Text("\t * ${preventionMethodsList[i]['methods'][j]}"),
                if (j == (preventionMethodsList[i]['methods'].length - 1)) ...{
                  Gaps.height(10)
                }
              }
            },
            Gaps.height(100),
            Center(
              child: Button(text: Strings.home,function: () {
                Navigator.push(context, MaterialPageRoute(builder: (ctx)=>const Home()));
              },),
            ),
          ],
        ),
      ),
    );
  }
}
