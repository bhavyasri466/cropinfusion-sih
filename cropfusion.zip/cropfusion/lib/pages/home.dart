import 'dart:io';
import 'package:flutter/material.dart';

// Custom Imports
import 'package:cropfusion/controllers/export.dart';
import 'package:cropfusion/widgets/export.dart';
import 'package:cropfusion/utils/export.dart';

//Packages Import
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';

//Next Page
import './prediction.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final ImagePicker _picker = ImagePicker();
  List<String> labels = [
    Strings.soilType,
    Strings.plantStage,
    Strings.location,
    Strings.pincode,
  ];
  List<TextEditingController> textControllers = [
    HomeControllers.soilType,
    HomeControllers.plantStage,
    HomeControllers.location,
    HomeControllers.pinCode
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: TopNav(),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
             Header(),
            
            Gaps.height(15),

            for (int i = 0; i < labels.length; i++) ...{
              Text(labels[i]),
              Gaps.height(10),
              Feilds(hint: labels[i], controller: textControllers[i]),
              Gaps.height(10)
            },
            Row(
              children: [
               const Text(
                  Strings.imageUpload,
                ),
                Gaps.width(10),
                Expanded(
                    child: Center(
                  child: Button(
                    function: () async{
                      final status = await Permission.camera.status;
                      if (!status.isGranted) {
                        await Permission.camera.request();
                      } else {
                                    final XFile? image = await _picker.pickImage(source: ImageSource.camera);
    if (image != null) {
    Navigator.push(context, MaterialPageRoute(builder: (ctx)=>Prediction(imageFile: File(image.path),)));
    }
                      }
           
                    },
                    text: Strings.start,
                  ),
                ))
              ],
            )
          ],
        ),
      ),
    );
  }
}

