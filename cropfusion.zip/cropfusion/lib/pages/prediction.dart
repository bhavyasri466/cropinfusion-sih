import 'dart:io';
import 'package:flutter/material.dart';

//Custom imports
import 'package:cropfusion/controllers/export.dart';
import 'package:cropfusion/utils/export.dart';
import 'package:cropfusion/widgets/export.dart';

//Next Page
import './prevention.dart';

class Prediction extends StatefulWidget {
  File? imageFile;
  Prediction({super.key, this.imageFile});

  @override
  State<Prediction> createState() => _PredictionState();
}

class _PredictionState extends State<Prediction> {
  List<String> labels = [
    Strings.diseaseName,
    Strings.nValue,
    Strings.pValue,
    Strings.kValue,
  ];
  List<TextEditingController> textControllers = [
    PredictionControllers.diseaseName,
    PredictionControllers.nValue,
    PredictionControllers.pValue,
    PredictionControllers.kValue,
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: TopNav(),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Header(),
            Gaps.height(15),
            for (int i = 0; i < labels.length; i++) ...{
              Text(labels[i]),
              Gaps.height(10),
              Feilds(hint: labels[i], controller: textControllers[i]),
              Gaps.height(10)
            },
            Gaps.height(50),
            Center(child: Button(text: Strings.preventions,function: () {
              Navigator.push(context, MaterialPageRoute(builder: (ctx)=>const Prevention()));
            },)),
            Gaps.height(20),
            Center(
              child: SizedBox(
                width: 120,
                height: 120,
                child: widget.imageFile != null
                    ? Image.file(
                        widget.imageFile!,
                        fit: BoxFit.cover,
                      )
                    : const Center(
                        child: Text(Strings.noImage),
                      ),
              ),
            ),
            
          ],
        ),
      ),
    );
  }
}
