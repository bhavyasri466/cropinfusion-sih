import 'dart:core';

class Strings {
  static const String welcomeToCropInfusion =
      "Welcome to Crop Infusion-Paddy Care";
  static const String boardingText =
      "Paddy Care is your go-to platform for predicting and enhancing paddy crop yields. Our state-of-the art prediction modes and expert advice ensure you get the best results for your crop.";
  static const String login = "Login";
  static const String diseasePrediction = "Disease  Prediction";
  static const String imageUpload = "Image Upload";
  static const String start = "Start";
  static const String soilType = "Soil Type";
  static const String plantStage = "Plant Stage";
  static const String location = "Location";
  static const String pincode = "Pincode";
  static const String diseaseName = "Disease Name";
  static const String nValue = "n Value";
  static const String pValue = "P Value";
  static const String kValue = "K Value";
  static const String preventions = "Preventions";
  static const String noImage = "No Image Uploaded";
  static const String preventionMethods = "Prevention Methods";
  static const String home = "Home";
}
