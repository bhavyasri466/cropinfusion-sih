import 'package:cropfusion/utils/colors.dart';
import 'package:flutter/material.dart';

class TextStyles{
static const redText = TextStyle(color: AppColors.highLightTextColor);
static const appbarText = TextStyle(color: Colors.black,fontSize: 12);
static const buttonText = TextStyle(color: Colors.white);
}