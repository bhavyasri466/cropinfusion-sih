import 'package:flutter/material.dart';

class AppColors{
  static const Color highLightTextColor = Color(0xFFE31818);
  static const Color buttonColor = Color(0xFF31A955);
  static const Color disabledButtonColor = Colors.grey;
  static const Color transparent = Colors.transparent;
}