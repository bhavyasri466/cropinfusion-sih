class Images{
  static const String logo = "assets/logo.png";
  static const String boardingCropImage = "assets/mainbg.png";
  static const String transparentFarmers = "assets/transparent_farmers.png";
}