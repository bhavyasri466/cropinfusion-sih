import "package:flutter/material.dart";

class Gaps{
  static SizedBox width(double w){
    return SizedBox(width: w,);
  }
  static SizedBox height(double h){
    return SizedBox(height: h,);
  }
}