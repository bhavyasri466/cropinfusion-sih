Map<String,dynamic> preventionMethods = {
  "data":[
    {
      "heading":"Culture Methods",
      "methods":[
        "Burn the stubbles.",
        "Use optimum dose of fertilizers.",
        "Avoid clipping of tip of seedling at the time of transplanting.",
        "Avoid flooded conditions.",
        "Remove weed hosts periodically."
      ]
    },
    {
      "heading": "Chemical method",
      "methods":[
        "Avoid clipping of leaf tips during transplantation.",
        "Spray Streptomycin sulphate and tetracycline combination 120g + Copper oxychloride 500 g/ha."
      ]
    }
  ]
};