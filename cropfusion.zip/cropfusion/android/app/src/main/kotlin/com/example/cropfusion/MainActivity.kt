package com.skybate.cropfusion

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
